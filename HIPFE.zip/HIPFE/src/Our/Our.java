package Our;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;

import static java.lang.System.out;

public class Our {

    public static void setup(String pairingFile, String publicFile,String mskFile,Element[] h,String AC,int l) { //AC do

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element g1 = bp.getG1().newRandomElement().getImmutable();
        Element g2 = bp.getG1().newRandomElement().getImmutable();
        Element u=bp.pairing(g1,g2).getImmutable();
        Element g3 = bp.getG1().newRandomElement().getImmutable();
        Element a=bp.getZr().newRandomElement().getImmutable();

        Element g0 = g2.powZn(a).getImmutable(); //主私钥
        Properties mskProp = loadPropFromFile(mskFile);
        mskProp.setProperty("g0_"+AC, Base64.getEncoder().encodeToString(g0.toBytes()));//element和string类型之间的转换需要通过bytes
        storePropToFile(mskProp, mskFile);

        Properties pubProp =new Properties();
        for (int i = 1; i < l+1; i++){
            h[i]=bp.getG1().newRandomElement().getImmutable();
            pubProp.setProperty("h_" + i,h[i].toString());
        }
        pubProp.setProperty("g",g.toString());
        pubProp.setProperty("g1",g1.toString());
        pubProp.setProperty("g2",g2.toString());
        pubProp.setProperty("g3",g3.toString());
        pubProp.setProperty("u",u.toString());
        storePropToFile(pubProp,publicFile);


    }


    //Registration阶段
    public static void Registration_KeyGen(String pairingFile,String publicFile,String mskFile,String skFile,String veriFile,int[] ID_k,Element[] y,int n,int k,int l,String AC) throws NoSuchAlgorithmException {

        //获得公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String g3str=pubProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        Element[] h=new Element[l+1];
        for(int i=1;i<l+1;i++){
            String histr=pubProp.getProperty("h_"+i);
            h[i] = bp.getG1().newElementFromBytes(histr.getBytes()).getImmutable();
        }
        Properties mskp=loadPropFromFile(mskFile);
        String g0str=mskp.getProperty("g0_"+AC);
        Element g0=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(g0str)).getImmutable();

        Properties skp=loadPropFromFile(skFile);
        Properties verp=loadPropFromFile(veriFile);
        //为身份为IDk的用户生成私钥
        Element[] yi=new Element[n+1];
        Element ysum=bp.getZr().newZeroElement();
        for (int i = 1; i < n+1; i++) {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            ysum = ysum.add(yi[i]);
            skp.setProperty("y"+i,Base64.getEncoder().encodeToString(yi[i].toBytes()));//sk
            verp.setProperty("y"+i,Base64.getEncoder().encodeToString(yi[i].toBytes()));
            skp.setProperty("ysum"+AC,Base64.getEncoder().encodeToString(ysum.toBytes()));//
        }
        Element r=bp.getZr().newRandomElement().getImmutable();
        Element[] IDk=new Element[k+1];
        for (int j = 1; j < k+1; j++) {
            IDk[j] = bp.getZr().newElementFromBytes(String.valueOf(ID_k[j]).getBytes()).getImmutable();
        }
        Element K0=g0.powZn(ysum).mul((h[1].powZn(IDk[1]).mul(g3)).powZn(r)).getImmutable();
        for(int j = 2; j < k+1; j++){
            K0=K0.mul(h[j].powZn(IDk[j].mul(r))).getImmutable();
        }
        skp.setProperty("K0_"+ID_k,Base64.getEncoder().encodeToString(K0.toBytes()));//sk
        Element K1=g.powZn(r).getImmutable();
        Element[] S=new Element[l+1];
        for(int i=k;i<l+1;i++){
            S[i]=h[i].powZn(r).getImmutable();
            skp.setProperty("S_"+i+ID_k,Base64.getEncoder().encodeToString(S[i].toBytes()));//sk
        }

        skp.setProperty("K1_"+ID_k,Base64.getEncoder().encodeToString(K1.toBytes()));
        storePropToFile(skp,skFile);
        storePropToFile(verp,veriFile);
    }
    public static void Enc(String pairingFile,String publicFile,String veriFile,int[] ID_k,Element[] x,int n,int k,int l,String AC) throws NoSuchAlgorithmException {

        //获得公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String g1str=pubProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String g2str=pubProp.getProperty("g2");
        Element g2 = bp.getG1().newElementFromBytes(g2str.getBytes()).getImmutable();
        String g3str=pubProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        String ustr=pubProp.getProperty("u");
        Element u = bp.getGT().newElementFromBytes(ustr.getBytes()).getImmutable();
        Element[] h=new Element[l+1];
        for(int i=1;i<l+1;i++){
            String histr=pubProp.getProperty("h_"+i);
            h[i] = bp.getG1().newElementFromBytes(histr.getBytes()).getImmutable();
        }
        Properties verp=loadPropFromFile(veriFile);

        //根据信息向量x为用户P生成密文
        Element[] xi=new Element[n+1];
        Element xsum=bp.getZr().newZeroElement();
        for (int i = 1; i < n+1; i++) {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable();
            xsum = xsum.add(xi[i]);
            verp.setProperty("x"+i,xi[i].toString());
            verp.setProperty("xsum"+AC,xsum.toString());
        }
        Element s=bp.getZr().newRandomElement().getImmutable();
        Element[] IDk=new Element[k+1];
        for (int j = 1; j < k+1; j++) {
            IDk[j] = bp.getZr().newElementFromBytes(String.valueOf(ID_k[j]).getBytes()).getImmutable();
        }
        Element C1=u.powZn(s.add(xsum)).getImmutable();
        Element C2=g.powZn(s).getImmutable();
        Element C3=h[1].powZn(IDk[1]).mul(g3).powZn(s).getImmutable();
        for(int j = 2; j < k+1; j++){
            C3=C3.mul(h[j].powZn(IDk[j].mul(s))).getImmutable();
        }
        pubProp.setProperty("C1"+ID_k,C1.toString());
        pubProp.setProperty("C2"+ID_k,C1.toString());
        pubProp.setProperty("C3"+ID_k,C1.toString());
        storePropToFile(verp,veriFile);
        storePropToFile(pubProp,publicFile);

    }

    public static void Dec(String pairingFile,String publicFile,String mskFile,String skFile,String veriFile,int[] ID_k,String AC) throws NoSuchAlgorithmException {

        //获得公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String g3str=pubProp.getProperty("g3");
        Element g3 = bp.getG1().newElementFromBytes(g3str.getBytes()).getImmutable();
        //获得密文
        String C1str=pubProp.getProperty("C1"+ID_k);
        Element C1 = bp.getG1().newElementFromBytes(C1str.getBytes()).getImmutable();
        String C2str=pubProp.getProperty("C2"+ID_k);
        Element C2 = bp.getG1().newElementFromBytes(C2str.getBytes()).getImmutable();
        String C3str=pubProp.getProperty("C3"+ID_k);
        Element C3 = bp.getG1().newElementFromBytes(C3str.getBytes()).getImmutable();
        Properties mskp=loadPropFromFile(mskFile);
        //用户IDk的私钥
        Properties skp=loadPropFromFile(skFile);
        String ysumstr=skp.getProperty("ysum"+AC);
        Element ysum=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(ysumstr)).getImmutable();
        String K0str=skp.getProperty("K0_"+ID_k);
        Element K0=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(K0str)).getImmutable();
        String K1str=skp.getProperty("K1_"+ID_k);
        Element K1=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(K1str)).getImmutable();
        //解密
        Properties verp=loadPropFromFile(veriFile);
        Element A1=C1.powZn(ysum).getImmutable();
        Element A2=bp.pairing(C3,K1).getImmutable();
        Element A3=bp.pairing(C2,K0).getImmutable();
        Element result=A1.mulZn(A2).mulZn(A3.invert()).getImmutable();
        verp.setProperty("Dec_"+ID_k,result.toString());

    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        /*
        指定配置文件的路径
         */
        int l=20; //层次身份的最大深度
        Element[] h=new Element[l+1];//实际下标从1开始，所以add 1.
        int n=25; //向量的维度
        Element[] x = new Element[n+1]; //与方案统一下标，x的下标从1开始，维度为5
        Element[] y = new Element[n+1];

        int k=5;//用户层次身份的深度
        int[] ID_k = new int[k+1];
        Random random = new Random();
        for (int j = 1; j < k+1; j++) {
            ID_k[j] = random.nextInt(100);
        }

        String dir = "./storeFile/Our/"; //根路径
        String pairingParametersFileName = dir + "a.properties";
        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String verifyFileName=dir+"veri.properties";

        String AC = "AC";

        for (int i = 0; i < 10; i++) {
            long start = System.currentTimeMillis();
            long start1 = System.currentTimeMillis();
            setup(pairingParametersFileName,publicParameterFileName,mskFileName,h,AC,l);
            long end1 = System.currentTimeMillis();
            System.out.println(end1-start1+"_setup");
            long start2= System.currentTimeMillis();
            Registration_KeyGen(pairingParametersFileName,publicParameterFileName,mskFileName,secretKeyFileName,verifyFileName,ID_k,y,n,k,l,AC);
            long end2 = System.currentTimeMillis();
            System.out.println(end2-start2+"_keygen");
            long start3= System.currentTimeMillis();
            Enc(pairingParametersFileName,publicParameterFileName,verifyFileName,ID_k,x,n,k,l,AC);
            long end3 = System.currentTimeMillis();
            System.out.println(end3-start3+"_enc");
            long start4= System.currentTimeMillis();
            Dec(pairingParametersFileName,publicParameterFileName,mskFileName,secretKeyFileName,verifyFileName,ID_k,AC);
            long end4 = System.currentTimeMillis();
            System.out.println(end4-start4+"_dec");
            long end = System.currentTimeMillis();
            System.out.println(end - start+"_totaltime");
        }


    }
}
