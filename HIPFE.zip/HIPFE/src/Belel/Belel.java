package Belel;

import it.unisa.dia.gas.jpbc.Element;
import it.unisa.dia.gas.jpbc.Pairing;
import it.unisa.dia.gas.plaf.jpbc.pairing.PairingFactory;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Properties;
import java.util.Random;

import static java.lang.System.out;

public class Belel {

    public static void setup(String pairingFile, String publicFile,String mskFile,Element[] h,Element[] hhat,String KGC,int d,int n) { //KGC do

        //第一个变量是公共的参数文件，第二个变量是公共变量文件，第三个变量是主私钥变量文件
        Pairing bp = PairingFactory.getPairing(pairingFile);  //用于生成群G或者Zq元素的对象
        Element g = bp.getG1().newRandomElement().getImmutable();
        Element ghat = bp.getG1().newRandomElement().getImmutable();
        Element u=bp.pairing(g,ghat).getImmutable();
        Element a=bp.getZr().newRandomElement().getImmutable();
        Element g1 = g.powZn(a).getImmutable();
        Element g1hat = ghat.powZn(a).getImmutable();
        Element[] delta=new Element[d+1];

        Properties pubProp =new Properties();
        for(int i=1;i<d+1;i++){
            delta[i]= bp.getZr().newRandomElement().getImmutable();
            h[i]=g.powZn(delta[i]).getImmutable();
            hhat[i]=ghat.powZn(delta[i]).getImmutable();
            pubProp.setProperty("h_" + i,h[i].toString()); //公共参数的内容 PK
            pubProp.setProperty("hhat_" + i,hhat[i].toString()); //公共参数的内容
        }

        Element b=bp.getZr().newRandomElement().getImmutable();
        Element[] gamma=new Element[n+1];
        for(int i=1;i<n+1;i++){
            gamma[i]= bp.getZr().newRandomElement().getImmutable();
        }
        Element[] g_0=new Element[n+1];
        Element[] w=new Element[n+1];
        Element v=u.powZn(a.mul(b)).getImmutable();
        for(int i=1;i<n+1;i++){
            g_0[i]= g1hat.powZn(b.mul(gamma[i])).getImmutable();
            w[i]=v.powZn(gamma[i]).getImmutable();
            pubProp.setProperty("w_" + i,w[i].toString());//PK
        }
        Properties mskProp = loadPropFromFile(mskFile);
        for(int i=1;i<n+1;i++){ //存储主私钥MSK
            mskProp.setProperty("g0i_"+i+KGC, Base64.getEncoder().encodeToString(g_0[i].toBytes()));//element和string类型之间的转换需要通过bytes
        }
        storePropToFile(mskProp, mskFile);

        pubProp.setProperty("g",g.toString());
        pubProp.setProperty("g1",g1.toString());
        pubProp.setProperty("ghat",ghat.toString());
        pubProp.setProperty("g1hat",g1hat.toString());
        pubProp.setProperty("u",u.toString());
        storePropToFile(pubProp,publicFile);

    }


    //Registration阶段
    public static void KeyGen(String pairingFile,String publicFile,String mskFile,String skFile,String veriFile,int[] HID_l,Element[] y,Element[] hhat,int n,int l,String KGC) throws NoSuchAlgorithmException {

        //获得公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String ghatstr=pubProp.getProperty("ghat");
        Element ghat = bp.getG1().newElementFromBytes(ghatstr.getBytes()).getImmutable();
        String g1hatstr=pubProp.getProperty("g1hat");
        Element g1hat = bp.getG1().newElementFromBytes(g1hatstr.getBytes()).getImmutable();

        Properties mskp=loadPropFromFile(mskFile);
        Element[] g_0=new Element[n+1];
        for(int i=1;i<n+1;i++){
            String g0istr=mskp.getProperty("g0i_"+i+KGC);
            g_0[i]=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(g0istr)).getImmutable();
        }

        Properties skp=loadPropFromFile(skFile);
        Properties verp=loadPropFromFile(veriFile);
        //为身份为IDk的用户生成私钥
        Element[] yi=new Element[n+1];

        for (int i = 1; i < n+1; i++) {
            yi[i] = bp.getZr().newElementFromBytes(String.valueOf(y[i]).getBytes()).getImmutable();
            skp.setProperty("y"+i,Base64.getEncoder().encodeToString(yi[i].toBytes()));//sk
            verp.setProperty("y"+i,Base64.getEncoder().encodeToString(yi[i].toBytes()));
        }
        Element[] IDl=new Element[l+1];
        for (int j = 1; j < l+1; j++) {
            IDl[j] = bp.getZr().newElementFromBytes(String.valueOf(HID_l[j]).getBytes()).getImmutable();
        }
        Element[] r=new Element[l+1];
        Element[] D=new Element[l+1];
        for(int i=1;i<l+1;i++){
            r[i]= bp.getZr().newRandomElement().getImmutable();
            D[i]=ghat.powZn(r[i]).getImmutable();
            skp.setProperty("D_"+i+HID_l,Base64.getEncoder().encodeToString(D[i].toBytes()));//sk的一部分内容
        }

        Element D0=g_0[1].powZn(yi[1]).mul((g1hat.powZn(IDl[1]).mul(hhat[1])).powZn(r[1])).getImmutable();
        for(int i=2;i<n+1;i++){
            for(int k = 2; k < l+1; k++) {
                D0 = D0.mul(g_0[i].powZn(yi[i])).mul((g1hat.powZn(IDl[k]).mul(hhat[k])).powZn(r[k])).getImmutable();
            }
        }
        skp.setProperty("D0_"+HID_l,Base64.getEncoder().encodeToString(D0.toBytes()));//sk

        storePropToFile(skp,skFile);
        storePropToFile(verp,veriFile);
    }
    public static void Enc(String pairingFile,String publicFile,String veriFile,int[] HID_l,Element[] x,Element[] h,int n,int l) throws NoSuchAlgorithmException {

        //获得公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        String g1str=pubProp.getProperty("g1");
        Element g1 = bp.getG1().newElementFromBytes(g1str.getBytes()).getImmutable();
        String ustr=pubProp.getProperty("u");
        Element u = bp.getGT().newElementFromBytes(ustr.getBytes()).getImmutable();

        Properties verp=loadPropFromFile(veriFile);

        //根据向量x为HIDl生成密文
        Element[] E=new Element[n+1];
        Element[] xi=new Element[n+1];
        Element xsum=bp.getZr().newZeroElement();
        for (int i = 1; i < n+1; i++) {
            xi[i] = bp.getZr().newElementFromBytes(String.valueOf(x[i]).getBytes()).getImmutable();
            E[i]=u.powZn(xi[i]).getImmutable();
            //xsum = xsum.add(xi[i]);
            verp.setProperty("x"+i,xi[i].toString());
            //verp.setProperty("xsum"+KGC,xsum.toString());
            pubProp.setProperty("E_"+i+HID_l,E[i].toString());
        }

        Element s=bp.getZr().newRandomElement().getImmutable();
        Element C0=g.powZn(s).getImmutable();
        Element[] IDl=new Element[l+1];
        for (int j = 1; j < l+1; j++) {
            IDl[j] = bp.getZr().newElementFromBytes(String.valueOf(HID_l[j]).getBytes()).getImmutable();
        }
        Element[] C=new Element[l+1];
        for(int k = 1; k < l+1; k++){
            C[k]=g1.powZn(IDl[k]).mul(h[k]).powZn(s).getImmutable();
            pubProp.setProperty("C_"+k+HID_l,C[k].toString());
        }
        pubProp.setProperty("C0"+HID_l,C0.toString());
        storePropToFile(verp,veriFile);
        storePropToFile(pubProp,publicFile);
    }

    public static void Dec(String pairingFile,String publicFile,String mskFile,String skFile,String veriFile,int[] HID_l,int n,int l,String KGC) throws NoSuchAlgorithmException {

        //获得公共参数
        Pairing bp=PairingFactory.getPairing(pairingFile);
        Properties pubProp=loadPropFromFile(publicFile);
        String gstr=pubProp.getProperty("g");
        Element g = bp.getG1().newElementFromBytes(gstr.getBytes()).getImmutable();
        //获得密文
        Element[] E=new Element[n+1];
        for(int i=1;i<n+1;i++){
            String Eistr=pubProp.getProperty("E_"+i+HID_l);
            E[i] = bp.getG1().newElementFromBytes(Eistr.getBytes()).getImmutable();
        }
        String C0str=pubProp.getProperty("C0"+HID_l);
        Element C0 = bp.getG1().newElementFromBytes(C0str.getBytes()).getImmutable();
        Element[] C=new Element[l+1];
        for(int k=1;k<l+1;k++){
            String Ckstr=pubProp.getProperty("C_"+k+HID_l);
            C[k] = bp.getG1().newElementFromBytes(Ckstr.getBytes()).getImmutable();
        }

        //用户IDk的私钥
        Properties skp=loadPropFromFile(skFile);
        Element[] yi=new Element[n+1];
        for(int i=1;i<n+1;i++){
            String yistr=skp.getProperty("y"+i);
            yi[i]=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(yistr)).getImmutable();
        }
        String D0str=skp.getProperty("D0_"+HID_l);
        Element D0=bp.getG1().newElementFromBytes(Base64.getDecoder().decode(D0str)).getImmutable();
        Element[] D=new Element[l+1];
        for(int i=1;i<l+1;i++){
            String Distr=skp.getProperty("D_"+i+HID_l);
            D[i] = bp.getG1().newElementFromBytes(Base64.getDecoder().decode(Distr)).getImmutable();
        }

        //解密
        Properties verp=loadPropFromFile(veriFile);
        Element A1=E[1].powZn(yi[1]).getImmutable();
        for(int i=2;i<n+1;i++){
            A1=A1.mulZn(E[i].powZn(yi[i])).getImmutable();
        }
        Element A2=bp.pairing(C[1],D[1]).getImmutable();
        for(int k=2;k<l+1;k++){
            A2=A2.mulZn(bp.pairing(C[k],D[k])).getImmutable();
        }
        Element A3=bp.pairing(C0,D0).getImmutable();
        Element result=A1.mulZn(A2).mulZn(A3.invert()).getImmutable();
        verp.setProperty("Dec_"+HID_l,result.toString());

    }

    /*
    将程序变量数据存储到文件中
     */
    public static void storePropToFile(Properties prop, String fileName){
        try(FileOutputStream out = new FileOutputStream(fileName)){
            prop.store(out, null);
        }
        catch (IOException e) {
            e.printStackTrace();
            out.println(fileName + " save failed!");
            System.exit(-1);
        }
    }


    /*
    从文件中读取数据
     */
    public static Properties loadPropFromFile(String fileName) {
        Properties prop = new Properties();
        try (
                FileInputStream in = new FileInputStream(fileName)){
            prop.load(in);
        }
        catch (IOException e){
            e.printStackTrace();
            out.println(fileName + " load failed!");
            System.exit(-1);
        }
        return prop;
    }


    /*
    哈希函数
     */
    public static byte[] sha1(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-1");
        instance.update(content.getBytes());
        return instance.digest();
    }
    public static byte[] sha2(String content) throws NoSuchAlgorithmException {
        MessageDigest instance = MessageDigest.getInstance("SHA-256");
        instance.update(content.getBytes());
        return instance.digest();
    }

    public static void main(String[] args) throws NoSuchAlgorithmException, IOException {
        /*
        指定配置文件的路径
         */
        int d=10;//层次身份的最大深度
        Element[] h=new Element[d+1];//实际下标从1开始，所以add 1.
        Element[] hhat=new Element[d+1];
        int n=25;
        Element[] x = new Element[n+1]; //与方案统一下标，x的下标从1开始，维度为5
        Element[] y = new Element[n+1];

        int l=5;
        int[] HID_l = new int[l+1];
        Random random = new Random();
        for (int j = 1; j < l+1; j++) {
            HID_l[j] = random.nextInt(100);
        }

        String dir = "./storeFile/Our/"; //根路径
        String pairingParametersFileName = dir + "a.properties";
        String publicParameterFileName = dir + "pub.properties";
        String mskFileName = dir + "msk.properties";
        String publicKeyFileName=dir+"pk.properties";
        String secretKeyFileName=dir+"sk.properties";
        String verifyFileName=dir+"veri.properties";

        String KGC = "KGC";

        for (int i = 0; i < 5; i++) {
            long start = System.currentTimeMillis();
            long start1= System.currentTimeMillis();
            setup(pairingParametersFileName,publicParameterFileName,mskFileName,h,hhat,KGC,d,n);
            long end1 = System.currentTimeMillis();
            System.out.println(end1-start1+"_setup");
            long start2= System.currentTimeMillis();
            KeyGen(pairingParametersFileName,publicParameterFileName,mskFileName,secretKeyFileName,verifyFileName,HID_l,y,h,n,l,KGC);
            long end2 = System.currentTimeMillis();
            System.out.println(end2-start2+"_keygen");
            long start3= System.currentTimeMillis();
            Enc(pairingParametersFileName,publicParameterFileName,verifyFileName,HID_l,x,h,n,l);
            long end3 = System.currentTimeMillis();
            System.out.println(end3-start3+"_enc");
            long start4= System.currentTimeMillis();
            Dec(pairingParametersFileName,publicParameterFileName,mskFileName,secretKeyFileName,verifyFileName,HID_l,n,l,KGC);
            long end4 = System.currentTimeMillis();
            System.out.println(end4-start4+"_dec");
            long end = System.currentTimeMillis();
            System.out.println(end - start+"_total");
        }


    }
}
